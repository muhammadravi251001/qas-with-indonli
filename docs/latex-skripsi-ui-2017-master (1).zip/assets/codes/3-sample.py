def sample(args):
    print(args)
    return args
